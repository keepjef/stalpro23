from django import forms
from .models import *


class FeedBackForm(forms.Form):
    name = forms.CharField(max_length=255, label='Ваше имя:')
    phone = forms.CharField(max_length=255, label='Телефон:')
    addr = forms.CharField(max_length=255, label='Адрес:')

    def __init__(self, *args, **kwargs):
        super(FeedBackForm, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs = {'id': 'first_name', 'class': 'fio',
                                                  'placeholder': 'Ваше имя'}
        self.fields['phone'].widget.attrs = {'id': 'first_name', 'class': 'tel',
                                                  'placeholder': 'Ваш номер телефона'}
        self.fields['addr'].widget.attrs = {'id': 'addr', 'class': 'addr',
                                                  'placeholder': 'Ваш Адрес',}
